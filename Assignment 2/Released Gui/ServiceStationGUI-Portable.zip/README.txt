================================================================================
              SERVICE STATION GUI - PRODUCER/CONSUMER SIMULATION
           Operating Systems Assignment - Semaphore Implementation
================================================================================

PROJECT DESCRIPTION:
-------------------
This is a graphical simulation of the classic Producer-Consumer problem using
semaphores. The application demonstrates:

  • Cars (Producers) arriving and entering a waiting queue
  • Service Bays (Consumers) processing cars from the queue
  • Thread synchronization using custom Semaphore implementation
  • Real-time visual feedback with smooth animations
  • Configurable queue capacity (1-10 cars) and service bays (1-10 bays)
  • Adjustable simulation speed for testing different scenarios


================================================================================
                            QUICK START (EASIEST)
================================================================================

REQUIREMENTS FOR RUNNING THE .BAT FILE:
---------------------------------------
  • Windows operating system
  • Java 17 or higher installed on your system
  
  ⚠️ IMPORTANT: The .bat file needs Java to be installed!
  
  How to check if Java is installed:
    1. Open Command Prompt (press Windows key, type "cmd", press Enter)
    2. Type: java -version
    3. Press Enter
    
  If you see Java version information (17 or higher), you're good to go!
  If you see "'java' is not recognized...", you need to install Java first.
  
  Download Java here: https://www.oracle.com/java/technologies/downloads/
  (Download JDK 17 or higher)

  ✅ NO JAVAFX DOWNLOAD NEEDED - All JavaFX libraries are bundled in this ZIP!
  ✅ NO ADDITIONAL SETUP NEEDED - Just have Java installed!

HOW TO RUN:
  1. Extract this entire ZIP folder to any location on your computer
  2. Keep all files together in the same folder (especially the "lib" folder!)
  3. Double-click "Launch-ServiceStation.bat"
  4. The GUI will start automatically!
  5. Configure simulation parameters and click "Start"

That's it! The .bat file handles everything else automatically.


================================================================================
                   RUNNING THE CODE IN INTELLIJ IDEA
================================================================================

If you want to open and run the source code in IntelliJ IDEA, follow these
steps carefully:

STEP 1: DOWNLOAD JAVAFX SDK
---------------------------
  1. Go to the official JavaFX website:
     https://gluonhq.com/products/javafx/
  
  2. Download JavaFX SDK 25.0.1 (or latest version) for Windows
  
  3. Extract the downloaded ZIP file to a location on your computer
     Example: C:\javafx-sdk-25.0.1
  
  4. Remember this path - you'll need it in the next steps!


STEP 2: OPEN PROJECT IN INTELLIJ
---------------------------------
  1. Open IntelliJ IDEA
  
  2. Click "Open" and select the project folder containing the source code
  
  3. Wait for IntelliJ to index the project


STEP 3: ADD JAVAFX LIBRARY TO PROJECT
--------------------------------------
  1. In IntelliJ, go to:  File → Project Structure  (or press Ctrl+Alt+Shift+S)
  
  2. In the left panel, select "Libraries"
  
  3. Click the "+" button and select "Java"
  
  4. Navigate to your JavaFX SDK folder and select the "lib" subfolder
     Example: C:\javafx-sdk-25.0.1\lib
  
  5. Click "OK" to add all JavaFX JAR files
  
  6. Click "Apply" and "OK" to close the Project Structure dialog


STEP 4: CONFIGURE VM OPTIONS
-----------------------------
  1. In IntelliJ, go to:  Run → Edit Configurations...
  
  2. Select the main class "ServiceStationGUI" (or create a new configuration)
  
  3. In the "VM options" field, paste the following (adjust the path if needed):

     --module-path "C:\javafx-sdk-25.0.1\lib" --add-modules javafx.controls,javafx.fxml,javafx.graphics --enable-native-access=ALL-UNNAMED,javafx.graphics

     ⚠️ IMPORTANT: Replace "C:\javafx-sdk-25.0.1" with YOUR actual JavaFX path!
  
  4. Click "Apply" and "OK"


STEP 5: RUN THE APPLICATION
---------------------------
  1. Right-click on "ServiceStationGUI.java" in the Project Explorer
  
  2. Select "Run 'ServiceStationGUI.main()'"
  
  3. The GUI should compile and launch successfully!


================================================================================
                              FEATURES & USAGE
================================================================================

CONFIGURATION OPTIONS:
---------------------
  • Waiting Capacity (1-10):  Maximum number of cars that can wait in queue
  • Service Bays (1-10):      Number of service stations processing cars
  • Car IDs:                  Space or comma-separated list of car identifiers
  • Simulation Speed:         Time multiplier (0.1-20 seconds)

HOW TO USE:
----------
  1. Set your desired configuration parameters
  2. Click "Start" to begin the simulation
  3. Watch cars arrive, wait in queue, and get serviced
  4. Click "Reset" to stop and clear the simulation
  5. Adjust parameters and run again!

VISUAL ELEMENTS:
---------------
  • Service Bays Section:  Shows which bays are busy/available
  • Waiting Queue:         Displays cars waiting for service
  • Activity Log:          Real-time event logging
  • Stats Counter:         Tracks total cars served


================================================================================
                           TECHNICAL DETAILS
================================================================================

IMPLEMENTATION:
--------------
  • Language:              Java with JavaFX for GUI
  • Synchronization:       Custom Semaphore implementation (P and V operations)
  • Threading:             Multi-threaded producer-consumer pattern
  • Producer Threads:      Each car runs in its own thread
  • Consumer Threads:      Each service bay runs in its own thread
  • Shared Resource:       Queue protected by semaphores (mutex, empty, full)

FILES INCLUDED:
--------------
  • ServiceStationGUI.java - Main application source code
  • styles.css             - GUI styling and themes
  • Car.ico                - Application icon
  • Launch-ServiceStation.bat - Quick launcher script
  • README.txt             - This file
  • lib/                   - JavaFX runtime libraries (JARs and DLLs)


================================================================================
                            TROUBLESHOOTING
================================================================================

IF THE .BAT FILE DOESN'T WORK:
-----------------------------
  ✓ Make sure Java is installed: Open Command Prompt and type "java -version"
  ✓ Ensure all files from the ZIP are in the same folder
  ✓ Don't move the "lib" folder - it must stay with the .bat file

IF INTELLIJ WON'T RUN THE CODE:
-------------------------------
  ✓ Verify JavaFX SDK is downloaded and extracted
  ✓ Check that the library path in VM options matches your JavaFX location
  ✓ Make sure you added the JavaFX lib folder in Project Structure → Libraries
  ✓ Rebuild the project: Build → Rebuild Project

IF YOU SEE "NO SUITABLE PIPELINE FOUND" ERROR:
---------------------------------------------
  ✓ This means JavaFX can't find native DLLs
  ✓ Use the .bat launcher instead - it handles this automatically
  ✓ Or ensure VM options include: --enable-native-access=ALL-UNNAMED,javafx.graphics


================================================================================
                              CONTACT & NOTES
================================================================================

This project was created as part of an Operating Systems course assignment
to demonstrate understanding of:
  • Process synchronization
  • Semaphores and mutual exclusion
  • Producer-Consumer problem
  • Multi-threaded programming
  • GUI development with JavaFX

Thank you for testing this application! 🚗💨

================================================================================
